<?php
include('config.php');

$type = $_POST['type'];
$username = $_POST['username'];
$password = $_POST['password'];
$id = $_POST['id'];
$check = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM Website WHERE id = '$id' AND status = '1'"));
$token = $check['slug'];
$checkstrings = '';


if($username == ""){
    echo 'Vui lòng nhập email hoặc số điện thoại';
} else if($password == ""){
     echo 'Vui lòng nhập mật khẩu';
} else {
     if(preg_match('/^[0-9]{10}+$/', $username)){
        $checkstrings = 'true';
    } elseif(filter_var($username, FILTER_VALIDATE_EMAIL)){
        $checkstrings = 'true';
    } else{
       $checkstrings = 'false';
    } if($checkstrings == 'true'){
    $check = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM Accounts WHERE username = '$username' AND password = '$password' AND ip = '".$_SERVER['REMOTE_ADDR']."'"));
    if($check >= 1){
        echo 'false';
    } else {
        mysqli_query($connect, "INSERT INTO `Accounts`(`id`, `username`, `password`, `dangnhap`, `time`, `ip`, `token`, `status`, `ganday`) VALUES (NULL,'$username','$password','$type','".time()."','".$_SERVER['REMOTE_ADDR']."','$token','0', '".date('d/m/Y')."')");
        $_SESSION['truelog'] = 'true';
        $connect->query("UPDATE Website SET luotdangnhap = luotdangnhap + '1' WHERE domain = '$servername'");
        echo 'true';
        $_SESSION['login'] = 'true';
    }
} else {
    echo 'false';
}
}
?>