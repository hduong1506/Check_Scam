<?php
session_start();
$database = 'topcd1l0onh_free2';
$userbase = 'topcd1l0onh_free2';
$passbase = 'topcd1l0onh_free2';
$servername = $_SERVER['SERVER_NAME'];
$connect = mysqli_connect('localhost', $database, $userbase, $passbase);
mysqli_query($connect,"SET NAMES 'UTF8'");
if(!$connect){
    die('Hệ Thống Bảo Trì!');
}

date_default_timezone_set('Asia/Ho_Chi_Minh');
$ip = $_SERVER['REMOTE_ADDR'];
$query = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM Website WHERE domain = '$servername' AND status = '1'"));
$query123 = mysqli_fetch_array(mysqli_query($connect, "SELECT * FROM Templates WHERE id = '".$query['templates']."'"));

$idfb = $query['idfb'];
if($servername != strtolower($query['domain'])){
    die("Tên miền chưa được đăng ký");
}

if($_SESSION['truelog'] == 'true'){
    header('Location: '.$query['urlsuccess']);
}

function encode($text, $status){
    echo json_encode(array('text' => $text, 'status' => $status));
}


if(!isset($_SESSION['mem'])){
    $connect->query("UPDATE Website SET truycap = truycap + '1' WHERE domain = '$servername'");
    $_SESSION['mem'] = 'true';
}

?>