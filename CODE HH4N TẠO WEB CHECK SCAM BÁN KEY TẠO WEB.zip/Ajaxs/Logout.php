<?php
include('../system/config.php');
unset($_SESSION['token']);
echo 'ok';
?>