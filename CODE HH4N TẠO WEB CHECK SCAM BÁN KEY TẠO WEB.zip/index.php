<?php
include('page/home.php');

/* (  
 Vui Lòng Không Xóa Dòng Này Để Tôn Trọng Tác Giả
 - Name: Nguyễn Thành 
 - Năm Sinh: 2005
 - Facebook: fb.com/iamthanh.xdeveloper
) *\
?>