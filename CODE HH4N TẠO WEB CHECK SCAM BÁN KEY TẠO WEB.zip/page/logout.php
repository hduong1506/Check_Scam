<?php
include('../system/config.php');
unset($_SESSION['key']);
unset($_SESSION['token']);
load('/');
?>