<script>
    	function logout(){
	   $.ajax({
        url: "/Ajaxs/Logout.php",
        method: "POST",
        data: {
           
        },
        success: function(response) {
            if(response == 'ok'){
                 alert('Đăng Xuất Thành Công!');
                 window.location.href="/";
            } else {
               alert('Đăng Xuất Thất Bại!');
            }
          
        }
    });
	 }
</script>

   
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="/js/vendors/alpinejs.min.js" defer=""></script>
    <script src="/js/main.js"></script><script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    
    </body>

</html>
