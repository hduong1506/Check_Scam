<html class="swal2-shown">
    <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <script src="https://connect.facebook.net/signals/config/4701744576586436?v=2.9.110&amp;r=stable" async=""></script>

  <link rel="stylesheet" href="https://cdn.vn.garenanow.com/web/kg/lvn2023/index-65f7add2.css">
  <script type="module">import.meta.url;import("_").catch(()=>1);async function* g(){};if(location.protocol!="file:"){window.__vite_is_modern_browser=true}</script>
  <script type="module">!function(){if(window.__vite_is_modern_browser)return;console.warn("vite: loading legacy chunks, syntax error above and the same error below should be ignored");var e=document.getElementById("vite-legacy-polyfill"),n=document.createElement("script");n.src=e.src,n.onload=function(){System.import(document.getElementById('vite-legacy-entry').getAttribute('data-src'))},document.body.appendChild(n)}();</script>
<style>.swal2-popup.swal2-toast{box-sizing:border-box;grid-column:1/4 !important;grid-row:1/4 !important;grid-template-columns:min-content auto min-content;padding:1em;overflow-y:hidden;background:#fff;box-shadow:0 0 1px rgba(0,0,0,.075),0 1px 2px rgba(0,0,0,.075),1px 2px 4px rgba(0,0,0,.075),1px 3px 8px rgba(0,0,0,.075),2px 4px 16px rgba(0,0,0,.075);pointer-events:all}.swal2-popup.swal2-toast>*{grid-column:2}.swal2-popup.swal2-toast .swal2-title{margin:.5em 1em;padding:0;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-loading{justify-content:center}.swal2-popup.swal2-toast .swal2-input{height:2em;margin:.5em;font-size:1em}.swal2-popup.swal2-toast .swal2-validation-message{font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{grid-column:3/3;grid-row:1/99;align-self:center;width:.8em;height:.8em;margin:0;font-size:2em}.swal2-popup.swal2-toast .swal2-html-container{margin:.5em 1em;padding:0;overflow:initial;font-size:1em;text-align:initial}.swal2-popup.swal2-toast .swal2-html-container:empty{padding:0}.swal2-popup.swal2-toast .swal2-loader{grid-column:1;grid-row:1/99;align-self:center;width:2em;height:2em;margin:.25em}.swal2-popup.swal2-toast .swal2-icon{grid-column:1;grid-row:1/99;align-self:center;width:2em;min-width:2em;height:2em;margin:0 .5em 0 0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:bold}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{justify-content:flex-start;height:auto;margin:0;margin-top:.5em;padding:0 .5em}.swal2-popup.swal2-toast .swal2-styled{margin:.25em .5em;padding:.4em .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.8em;left:-0.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{animation:swal2-toast-hide .1s forwards}div:where(.swal2-container){display:grid;position:fixed;z-index:1060;inset:0;box-sizing:border-box;grid-template-areas:"top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";grid-template-rows:minmax(min-content, auto) minmax(min-content, auto) minmax(min-content, auto);height:100%;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}div:where(.swal2-container).swal2-backdrop-show,div:where(.swal2-container).swal2-noanimation{background:rgba(0,0,0,.4)}div:where(.swal2-container).swal2-backdrop-hide{background:rgba(0,0,0,0) !important}div:where(.swal2-container).swal2-top-start,div:where(.swal2-container).swal2-center-start,div:where(.swal2-container).swal2-bottom-start{grid-template-columns:minmax(0, 1fr) auto auto}div:where(.swal2-container).swal2-top,div:where(.swal2-container).swal2-center,div:where(.swal2-container).swal2-bottom{grid-template-columns:auto minmax(0, 1fr) auto}div:where(.swal2-container).swal2-top-end,div:where(.swal2-container).swal2-center-end,div:where(.swal2-container).swal2-bottom-end{grid-template-columns:auto auto minmax(0, 1fr)}div:where(.swal2-container).swal2-top-start>.swal2-popup{align-self:start}div:where(.swal2-container).swal2-top>.swal2-popup{grid-column:2;align-self:start;justify-self:center}div:where(.swal2-container).swal2-top-end>.swal2-popup,div:where(.swal2-container).swal2-top-right>.swal2-popup{grid-column:3;align-self:start;justify-self:end}div:where(.swal2-container).swal2-center-start>.swal2-popup,div:where(.swal2-container).swal2-center-left>.swal2-popup{grid-row:2;align-self:center}div:where(.swal2-container).swal2-center>.swal2-popup{grid-column:2;grid-row:2;align-self:center;justify-self:center}div:where(.swal2-container).swal2-center-end>.swal2-popup,div:where(.swal2-container).swal2-center-right>.swal2-popup{grid-column:3;grid-row:2;align-self:center;justify-self:end}div:where(.swal2-container).swal2-bottom-start>.swal2-popup,div:where(.swal2-container).swal2-bottom-left>.swal2-popup{grid-column:1;grid-row:3;align-self:end}div:where(.swal2-container).swal2-bottom>.swal2-popup{grid-column:2;grid-row:3;justify-self:center;align-self:end}div:where(.swal2-container).swal2-bottom-end>.swal2-popup,div:where(.swal2-container).swal2-bottom-right>.swal2-popup{grid-column:3;grid-row:3;align-self:end;justify-self:end}div:where(.swal2-container).swal2-grow-row>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-column:1/4;width:100%}div:where(.swal2-container).swal2-grow-column>.swal2-popup,div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup{grid-row:1/4;align-self:stretch}div:where(.swal2-container).swal2-no-transition{transition:none !important}div:where(.swal2-container) div:where(.swal2-popup){display:none;position:relative;box-sizing:border-box;grid-template-columns:minmax(0, 100%);width:32em;max-width:100%;padding:0 0 1.25em;border:none;border-radius:5px;background:#fff;color:#545454;font-family:inherit;font-size:1rem}div:where(.swal2-container) div:where(.swal2-popup):focus{outline:none}div:where(.swal2-container) div:where(.swal2-popup).swal2-loading{overflow-y:hidden}div:where(.swal2-container) h2:where(.swal2-title){position:relative;max-width:100%;margin:0;padding:.8em 1em 0;color:inherit;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}div:where(.swal2-container) div:where(.swal2-actions){display:flex;z-index:1;box-sizing:border-box;flex-wrap:wrap;align-items:center;justify-content:center;width:auto;margin:1.25em auto 0;padding:0}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.1))}div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2))}div:where(.swal2-container) div:where(.swal2-loader){display:none;align-items:center;justify-content:center;width:2.2em;height:2.2em;margin:0 1.875em;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border-width:.25em;border-style:solid;border-radius:100%;border-color:#2778c4 rgba(0,0,0,0) #2778c4 rgba(0,0,0,0)}div:where(.swal2-container) button:where(.swal2-styled){margin:.3125em;padding:.625em 1.1em;transition:box-shadow .1s;box-shadow:0 0 0 3px rgba(0,0,0,0);font-weight:500}div:where(.swal2-container) button:where(.swal2-styled):not([disabled]){cursor:pointer}div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#7066e0;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm:focus{box-shadow:0 0 0 3px rgba(112,102,224,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-deny{border:0;border-radius:.25em;background:initial;background-color:#dc3741;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-deny:focus{box-shadow:0 0 0 3px rgba(220,55,65,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#6e7881;color:#fff;font-size:1em}div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel:focus{box-shadow:0 0 0 3px rgba(110,120,129,.5)}div:where(.swal2-container) button:where(.swal2-styled).swal2-default-outline:focus{box-shadow:0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) button:where(.swal2-styled):focus{outline:none}div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner{border:0}div:where(.swal2-container) div:where(.swal2-footer){justify-content:center;margin:1em 0 0;padding:1em 1em 0;border-top:1px solid #eee;color:inherit;font-size:1em}div:where(.swal2-container) .swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;grid-column:auto !important;overflow:hidden;border-bottom-right-radius:5px;border-bottom-left-radius:5px}div:where(.swal2-container) div:where(.swal2-timer-progress-bar){width:100%;height:.25em;background:rgba(0,0,0,.2)}div:where(.swal2-container) img:where(.swal2-image){max-width:100%;margin:2em auto 1em}div:where(.swal2-container) button:where(.swal2-close){z-index:2;align-items:center;justify-content:center;width:1.2em;height:1.2em;margin-top:0;margin-right:0;margin-bottom:-1.2em;padding:0;overflow:hidden;transition:color .1s,box-shadow .1s;border:none;border-radius:5px;background:rgba(0,0,0,0);color:#ccc;font-family:monospace;font-size:2.5em;cursor:pointer;justify-self:end}div:where(.swal2-container) button:where(.swal2-close):hover{transform:none;background:rgba(0,0,0,0);color:#f27474}div:where(.swal2-container) button:where(.swal2-close):focus{outline:none;box-shadow:inset 0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner{border:0}div:where(.swal2-container) .swal2-html-container{z-index:1;justify-content:center;margin:1em 1.6em .3em;padding:0;overflow:auto;color:inherit;font-size:1.125em;font-weight:normal;line-height:normal;text-align:center;word-wrap:break-word;word-break:break-word}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea),div:where(.swal2-container) select:where(.swal2-select),div:where(.swal2-container) div:where(.swal2-radio),div:where(.swal2-container) label:where(.swal2-checkbox){margin:1em 2em 3px}div:where(.swal2-container) input:where(.swal2-input),div:where(.swal2-container) input:where(.swal2-file),div:where(.swal2-container) textarea:where(.swal2-textarea){box-sizing:border-box;width:auto;transition:border-color .1s,box-shadow .1s;border:1px solid #d9d9d9;border-radius:.1875em;background:rgba(0,0,0,0);box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(0,0,0,0);color:inherit;font-size:1.125em}div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror{border-color:#f27474 !important;box-shadow:0 0 2px #f27474 !important}div:where(.swal2-container) input:where(.swal2-input):focus,div:where(.swal2-container) input:where(.swal2-file):focus,div:where(.swal2-container) textarea:where(.swal2-textarea):focus{border:1px solid #b4dbed;outline:none;box-shadow:inset 0 1px 1px rgba(0,0,0,.06),0 0 0 3px rgba(100,150,200,.5)}div:where(.swal2-container) input:where(.swal2-input)::placeholder,div:where(.swal2-container) input:where(.swal2-file)::placeholder,div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder{color:#ccc}div:where(.swal2-container) .swal2-range{margin:1em 2em 3px;background:#fff}div:where(.swal2-container) .swal2-range input{width:80%}div:where(.swal2-container) .swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}div:where(.swal2-container) .swal2-range input,div:where(.swal2-container) .swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}div:where(.swal2-container) .swal2-input{height:2.625em;padding:0 .75em}div:where(.swal2-container) .swal2-file{width:75%;margin-right:auto;margin-left:auto;background:rgba(0,0,0,0);font-size:1.125em}div:where(.swal2-container) .swal2-textarea{height:6.75em;padding:.75em}div:where(.swal2-container) .swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:rgba(0,0,0,0);color:inherit;font-size:1.125em}div:where(.swal2-container) .swal2-radio,div:where(.swal2-container) .swal2-checkbox{align-items:center;justify-content:center;background:#fff;color:inherit}div:where(.swal2-container) .swal2-radio label,div:where(.swal2-container) .swal2-checkbox label{margin:0 .6em;font-size:1.125em}div:where(.swal2-container) .swal2-radio input,div:where(.swal2-container) .swal2-checkbox input{flex-shrink:0;margin:0 .4em}div:where(.swal2-container) label:where(.swal2-input-label){display:flex;justify-content:center;margin:1em auto 0}div:where(.swal2-container) div:where(.swal2-validation-message){align-items:center;justify-content:center;margin:1em 0 0;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}div:where(.swal2-container) div:where(.swal2-validation-message)::before{content:"!";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}div:where(.swal2-container) .swal2-progress-steps{flex-wrap:wrap;align-items:center;max-width:100%;margin:1.25em auto;padding:0;background:rgba(0,0,0,0);font-weight:600}div:where(.swal2-container) .swal2-progress-steps li{display:inline-block;position:relative}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step{z-index:20;flex-shrink:0;width:2em;height:2em;border-radius:2em;background:#2778c4;color:#fff;line-height:2em;text-align:center}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#2778c4}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line{z-index:10;flex-shrink:0;width:2.5em;height:.4em;margin:0 -1px;background:#2778c4}div:where(.swal2-icon){position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:2.5em auto .6em;border:0.25em solid rgba(0,0,0,0);border-radius:50%;border-color:#000;font-family:inherit;line-height:5em;cursor:default;user-select:none}div:where(.swal2-icon) .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}div:where(.swal2-icon).swal2-error{border-color:#f27474;color:#f27474}div:where(.swal2-icon).swal2-error .swal2-x-mark{position:relative;flex-grow:1}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-error.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark{animation:swal2-animate-error-x-mark .5s}div:where(.swal2-icon).swal2-warning{border-color:#facea8;color:#f8bb86}div:where(.swal2-icon).swal2-warning.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .5s}div:where(.swal2-icon).swal2-info{border-color:#9de0f6;color:#3fc3ee}div:where(.swal2-icon).swal2-info.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content{animation:swal2-animate-i-mark .8s}div:where(.swal2-icon).swal2-question{border-color:#c9dae1;color:#87adbd}div:where(.swal2-icon).swal2-question.swal2-icon-show{animation:swal2-animate-error-icon .5s}div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content{animation:swal2-animate-question-mark .8s}div:where(.swal2-icon).swal2-success{border-color:#a5dc86;color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=left]{top:-0.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}div:where(.swal2-icon).swal2-success [class^=swal2-success-circular-line][class$=right]{top:-0.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}div:where(.swal2-icon).swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-0.25em;left:-0.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}div:where(.swal2-icon).swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}div:where(.swal2-icon).swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip{animation:swal2-animate-success-line-tip .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long{animation:swal2-animate-success-line-long .75s}div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right{animation:swal2-rotate-success-circular-line 4.25s ease-in}[class^=swal2]{-webkit-tap-highlight-color:rgba(0,0,0,0)}.swal2-show{animation:swal2-show .3s}.swal2-hide{animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{margin-right:initial;margin-left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@keyframes swal2-toast-show{0%{transform:translateY(-0.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(0.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0deg)}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-0.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-show{0%{transform:scale(0.7)}45%{transform:scale(1.05)}80%{transform:scale(0.95)}100%{transform:scale(1)}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(0.5);opacity:0}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-0.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(0.4);opacity:0}50%{margin-top:1.625em;transform:scale(0.4);opacity:0}80%{margin-top:-0.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0deg);opacity:1}}@keyframes swal2-rotate-loading{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}@keyframes swal2-animate-question-mark{0%{transform:rotateY(-360deg)}100%{transform:rotateY(0)}}@keyframes swal2-animate-i-mark{0%{transform:rotateZ(45deg);opacity:0}25%{transform:rotateZ(-25deg);opacity:.4}50%{transform:rotateZ(15deg);opacity:.8}75%{transform:rotateZ(-5deg);opacity:1}100%{transform:rotateX(0);opacity:1}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto !important}body.swal2-no-backdrop .swal2-container{background-color:rgba(0,0,0,0) !important;pointer-events:none}body.swal2-no-backdrop .swal2-container .swal2-popup{pointer-events:all}body.swal2-no-backdrop .swal2-container .swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll !important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static !important}}body.swal2-toast-shown .swal2-container{box-sizing:border-box;width:360px;max-width:100%;background-color:rgba(0,0,0,0);pointer-events:none}body.swal2-toast-shown .swal2-container.swal2-top{inset:0 auto auto 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{inset:0 0 auto auto}body.swal2-toast-shown .swal2-container.swal2-top-start,body.swal2-toast-shown .swal2-container.swal2-top-left{inset:0 auto auto 0}body.swal2-toast-shown .swal2-container.swal2-center-start,body.swal2-toast-shown .swal2-container.swal2-center-left{inset:50% auto auto 0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{inset:50% auto auto 50%;transform:translate(-50%, -50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{inset:50% 0 auto auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-start,body.swal2-toast-shown .swal2-container.swal2-bottom-left{inset:auto auto 0 0}body.swal2-toast-shown .swal2-container.swal2-bottom{inset:auto auto 0 50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{inset:auto 0 0 auto}</style>
<title>Lịch vạn năng</title>
<meta name="description" content="Lịch vạn năng">
<link rel="icon" type="image/png" href="https://lichvannang.lienquan.garena.vn/img/favicon.jpg">
<meta name="keywords" content="aov,lienquan,lichvannang">

<style type="text/css" data-fbcssmodules="css:fb.css.base css:fb.css.dialog css:fb.css.iframewidget css:fb.css.customer_chat_plugin_iframe">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:'lucida grande', tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_dialog_advanced{border-radius:8px;padding:10px}.fb_dialog_content{background:#fff;color:#373737}.fb_dialog_close_icon{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{left:5px;right:auto;top:5px}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://connect.facebook.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://connect.facebook.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{height:100%;left:0;margin:0;overflow:visible;position:absolute;top:-10000px;transform:none;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://connect.facebook.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{background:none;height:auto;min-height:initial;min-width:initial;width:auto}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{clear:both;color:#fff;display:block;font-size:18px;padding-top:20px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .4);bottom:0;left:0;min-height:100%;position:absolute;right:0;top:0;width:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_mobile .fb_dialog_iframe{position:sticky;top:0}.fb_dialog_content .dialog_header{background:linear-gradient(from(#738aba), to(#2c4987));border-bottom:1px solid;border-color:#043b87;box-shadow:white 0 1px 1px -1px inset;color:#fff;font:bold 14px Helvetica, sans-serif;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:linear-gradient(from(#4267B2), to(#2a4887));background-clip:padding-box;border:1px solid #29487d;border-radius:3px;display:inline-block;line-height:18px;margin-top:3px;max-width:85px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{background:none;border:none;color:#fff;font:bold 12px Helvetica, sans-serif;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://connect.facebook.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #4a4a4a;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f5f6f7;border:1px solid #4a4a4a;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://connect.facebook.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-position:50% 50%;background-repeat:no-repeat;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}
.fb_mpn_mobile_landing_page_slide_out{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_out_from_left{animation-duration:200ms;animation-name:fb_mpn_landing_page_slide_out_from_left;transition-timing-function:ease-in}.fb_mpn_mobile_landing_page_slide_up{animation-duration:500ms;animation-name:fb_mpn_landing_page_slide_up;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_in{animation-duration:300ms;animation-name:fb_mpn_bounce_in;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out{animation-duration:300ms;animation-name:fb_mpn_bounce_out;transition-timing-function:ease-in}.fb_mpn_mobile_bounce_out_v2{animation-duration:300ms;animation-name:fb_mpn_fade_out;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_v2{animation-duration:300ms;animation-name:fb_bounce_in_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_in_from_left{animation-duration:300ms;animation-name:fb_bounce_in_from_left;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_v2{animation-duration:300ms;animation-name:fb_bounce_out_v2;transition-timing-function:ease-in}.fb_customer_chat_bounce_out_from_left{animation-duration:300ms;animation-name:fb_bounce_out_from_left;transition-timing-function:ease-in}.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}@keyframes fb_mpn_landing_page_slide_out{0%{margin:0 12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;margin:0 24px;width:60px}}@keyframes fb_mpn_landing_page_slide_out_from_left{0%{left:12px;width:100% - 24px}60%{border-radius:18px}100%{border-radius:50%;left:12px;width:60px}}@keyframes fb_mpn_landing_page_slide_up{0%{bottom:0;opacity:0}100%{bottom:24px;opacity:1}}@keyframes fb_mpn_bounce_in{0%{opacity:.5;top:100%}100%{opacity:1;top:0}}@keyframes fb_mpn_fade_out{0%{bottom:30px;opacity:1}100%{bottom:0;opacity:0}}@keyframes fb_mpn_bounce_out{0%{opacity:1;top:0}100%{opacity:.5;top:100%}}@keyframes fb_bounce_in_v2{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}50%{transform:scale(1.03, 1.03);transform-origin:bottom right}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}}@keyframes fb_bounce_in_from_left{0%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}50%{transform:scale(1.03, 1.03);transform-origin:bottom left}100%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}}@keyframes fb_bounce_out_v2{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom right}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom right}}@keyframes fb_bounce_out_from_left{0%{opacity:1;transform:scale(1, 1);transform-origin:bottom left}100%{opacity:0;transform:scale(0, 0);transform-origin:bottom left}}@keyframes slideInFromBottom{0%{opacity:.1;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}@keyframes slideInFromBottomDelay{0%{opacity:0;transform:translateY(100%)}97%{opacity:0;transform:translateY(100%)}100%{opacity:1;transform:translateY(0)}}</style>
</head>

<body class="swal2-shown">
  <div id="main" aria-hidden="true">
      <main class="wrapper">
      <header class="header">
      <img src="https://lichvannang.lienquan.garena.vn/img/logo.png" class="header__logo">
  <div class="header__menu">
      <a href="#">
      <img src="https://lichvannang.lienquan.garena.vn/img/btn-rules.png">
  </a>
  <a href="#">
      <img src="https://lichvannang.lienquan.garena.vn/img/btn-histories.png">
  </a>
  </div>
  <a href="#" class="header__login">
      <img src="https://lichvannang.lienquan.garena.vn/img/btn-login.png">
  </a>
  </header>
  <div class="calendar">
      <div class="calendar__note">Điểm danh hàng tháng để<span>&nbsp;CHẮC CHẮN NHẬN&nbsp;</span>trang phục&nbsp;<img src="https://lichvannang.lienquan.garena.vn/img/tag-ss.png">
  </div>
  <ul class="calendar__list">
      <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.01</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.02</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.03</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.04</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.05</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.06</div>
  </div>
  </li>
  <li>
      <div class="calendar__month active ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.07</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.08</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.09</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.10</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x100">
  <span>x100</span>
  </div>
  <div class="calendar__month--num">Th.11</div>
  </div>
  </li>
  <li>
      <div class="calendar__month  ">
      <div class="calendar__month--img">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin.png" alt="Chip Vạn Năng x200">
  <span>x200</span>
  </div>
  <div class="calendar__month--num">Th.12</div>
  </div>
  </li>
  </ul>
  <a href="#" class="calendar__checkin animate__animated animate__pulse animate__infinite">
      <img src="https://lichvannang.lienquan.garena.vn/img/btn-checkin.png">
  </a>
  </div>
  <div class="spin">
      <img src="https://lichvannang.lienquan.garena.vn/img/title-spin.png" class="spin__title">
  <div class="spin__main">
      <ul class="spin__items">
      <li id="slot1" style="overflow: hidden;">
      <div class="slotMachineContainer slotMachineGradient" style="transition: all 8s linear 0s; transform: matrix(1, 0, 0, 1, 0, -648);">
      <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  <span data-index="1" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-3.png" alt="Giấy tuyệt sắc x3">
  </span>
  <span data-index="2" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-4.png" alt="Giấy tuyệt sắc x4">
  </span>
  <span data-index="3" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-5.png" alt="Giấy tuyệt sắc x5">
  </span>
  <span data-index="4" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-10.png" alt="Giấy tuyệt sắc x10">
  </span>
  <span data-index="5" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-5.png" alt="Giấy S x5">
  </span>
  <span data-index="6" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-10.png" alt="Giấy S x10">
  </span>
  <span data-index="7" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-15.png" alt="Giấy S x15">
  </span>
  <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  </div>
  </li>
  <li id="slot2" style="overflow: hidden;">
      <div class="slotMachineContainer slotMachineGradient" style="transition: all 8s linear 0s; transform: matrix(1, 0, 0, 1, 0, -648);">
      <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  <span data-index="1" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-3.png" alt="Giấy tuyệt sắc x3">
  </span>
  <span data-index="2" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-4.png" alt="Giấy tuyệt sắc x4">
  </span>
  <span data-index="3" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-5.png" alt="Giấy tuyệt sắc x5">
  </span>
  <span data-index="4" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-10.png" alt="Giấy tuyệt sắc x10">
  </span>
  <span data-index="5" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-5.png" alt="Giấy S x5">
  </span>
  <span data-index="6" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-10.png" alt="Giấy S x10">
  </span>
  <span data-index="7" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-15.png" alt="Giấy S x15">
  </span>
  <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  </div>
  </li>
  <li id="slot3" style="overflow: hidden;">
      <div class="slotMachineContainer slotMachineGradient" style="transition: all 8s linear 0s; transform: matrix(1, 0, 0, 1, 0, -648);">
      <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  <span data-index="1" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-3.png" alt="Giấy tuyệt sắc x3">
  </span>
  <span data-index="2" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-4.png" alt="Giấy tuyệt sắc x4">
  </span>
  <span data-index="3" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-5.png" alt="Giấy tuyệt sắc x5">
  </span>
  <span data-index="4" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/chromadg-10.png" alt="Giấy tuyệt sắc x10">
  </span>
  <span data-index="5" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-5.png" alt="Giấy S x5">
  </span>
  <span data-index="6" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-10.png" alt="Giấy S x10">
  </span>
  <span data-index="7" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/premiumdg-15.png" alt="Giấy S x15">
  </span>
  <span data-index="8" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5itemicon/itemicon/pick1skin.png" alt="Rương trang phục thường">
  </span>
  <span data-index="0" class="slotMachineBlurFast">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/item/coin1k2.png" alt="Chip Vạn Năng x1200">
  </span>
  </div>
  </li>
  </ul>
  <a href="#" class="spin__btn ">
      <img src="https://lichvannang.lienquan.garena.vn/img/btn-spin.png">
  </a>
  </div>
  </div>
  <div class="exchange">
      <a href="#" class="exchange__btn">
      <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/H5_duet_2022/icon/13302.jpg">
  <span>Danh sách<br>quà</span>
  </a>
  <div class="exchange__artwork">
  <p>
  <img src="https://dl.ops.kgvn.garenanow.com/hok/client/web/h5_diligence_2023/image/valhein-5.png" class="animate__animated animate__fadeIn">
  </p>
  </div>
  <a href="#" class="exchange__receive animate__animated animate__pulse animate__infinite">
  <img src="https://lichvannang.lienquan.garena.vn/img/btn-receive.png">
  </a>
  </div>
  </main>
  </div>
  
  <script src="https://lichvannang.lienquan.garena.vn/js/jquery.min.js" aria-hidden="true">
      
  </script>
  <script src="https://lichvannang.lienquan.garena.vn/js/slotmachine.min.js" aria-hidden="true">
      
  </script>
  <script src="https://lichvannang.lienquan.garena.vn/js/jquery.slotmachine.min.js" aria-hidden="true">
      
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/web-animations/2.3.2/web-animations.min.js" aria-hidden="true">
      
  </script>
  <script nomodule="" aria-hidden="true">!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",(function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()}),!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}();</script>
  <script nomodule="" crossorigin="" id="vite-legacy-polyfill" src="https://cdn.vn.garenanow.com/web/kg/lvn2023/polyfills-legacy-674862ff.js" aria-hidden="true">
      
  </script>
  <script nomodule="" crossorigin="" id="vite-legacy-entry" data-src="https://cdn.vn.garenanow.com/web/kg/lvn2023/index-legacy-e47a994d.js" aria-hidden="true">System.import(document.getElementById('vite-legacy-entry').getAttribute('data-src'))</script>


<div id="fb-root" class=" fb_reset" aria-hidden="true">
    <div style="position: absolute; top: -10000px; width: 0px; height: 0px;">
    <div>
    
</div>
</div>
</div>
<div class="swal2-container swal2-center swal2-backdrop-show" style="overflow-y: auto;">
    <div aria-labelledby="swal2-title" aria-describedby="swal2-html-container" class="swal2-popup show-scaleY swal2-modal popup-alert popup-error" tabindex="-1" role="dialog" aria-live="assertive" aria-modal="true" style="display: grid;">
    <button type="button" class="swal2-close" aria-label="Close this dialog" style="display: flex;">
    <img src="https://lichvannang.lienquan.garena.vn/img/icon-close.png">
</button>
<ul class="swal2-progress-steps" style="display: none;">
    
</ul>
<div class="swal2-icon" style="display: none;">
    
</div>
<img class="swal2-image" style="display: none;">
<h2 class="swal2-title" id="swal2-title" style="display: block;">
    <span>Thông báo</span>
</h2>
<div class="swal2-html-container" id="swal2-html-container" style="display: block;">
    <div class="popup-alert__message">Vui lòng đăng nhập để tham gia sự kiện!</div>
      
      
      
      
        <div class="popup-alert__actions">
          <a href="https://lichvannang.lienquan.garena.vn/connect/garena?platform=3" title="Facebook">
            <img src="https://lichvannang.lienquan.garena.vn/img/logo-facebook.png" alt="Facebook">
          </a>
          <a href="https://lichvannang.lienquan.garena.vn/connect/garena" title="Garena">
            <img src="https://lichvannang.lienquan.garena.vn/img/logo-garena.png" alt="Garena">
          </a>
        </div>
      
    </div>
    <input class="swal2-input" style="display: none;">
    <input type="file" class="swal2-file" style="display: none;">
    <div class="swal2-range" style="display: none;">
        <input type="range">
    <output>
        
    </output>
    </div>
    <select class="swal2-select" style="display: none;">
        
    </select>
    <div class="swal2-radio" style="display: none;">
        
    </div>
    <label for="swal2-checkbox" class="swal2-checkbox" style="display: none;">
        <input type="checkbox">
    <span class="swal2-label">
        
    </span>
    </label>
    <textarea class="swal2-textarea" style="display: none;">
        
    </textarea>
    <div class="swal2-validation-message" id="swal2-validation-message" style="display: none;">
        
    </div>
    <div class="swal2-actions" style="display: none;">
        <button type="button" class="swal2-cancel swal2-styled" aria-label="" style="display: none;">Cancel</button>
    <button type="button" class="swal2-deny swal2-styled" aria-label="" style="display: none;">No</button>
    <button type="button" class="swal2-confirm swal2-styled" aria-label="" style="display: none;">OK</button>
    <div class="swal2-loader">
        
    </div>
    </div>
    <div class="swal2-footer" style="display: none;">
        
    </div>
    <div class="swal2-timer-progress-bar-container">
        <div class="swal2-timer-progress-bar" style="display: none;">
        
    </div>
    </div>
    </div>
    </div>
    </body>
    </html>