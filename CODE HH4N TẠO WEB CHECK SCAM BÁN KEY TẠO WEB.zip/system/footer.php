
<script>
    function logout(){
        window.location.href="/logout";
    }
</script>

<div id="result"></div>
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="/js/vendors/alpinejs.min.js" defer=""></script>
    <script src="/js/main.js"></script><script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>

</body>
</html>